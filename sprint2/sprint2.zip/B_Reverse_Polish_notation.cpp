#include <iostream>
#include <sstream>
#include <stack>
#include <cmath> // std::floor
//https://contest.yandex.ru/contest/22781/run-report/117369660/
/*
  If an operand is fed to the input, it is placed on the top of the stack.
  If an operation sign is fed to the input, 
then this operation is performed on the required number of values
​​taken from the stack in the order of addition. 
The result of the performed operation is placed on the top of the stack.

  If the input set of symbols is not fully processed, go to step 1.
After the input set of symbols is fully processed, 
the result of calculating the expression is at the top of the stack. 
If there are several numbers left on the stack, 
then only the top element should be output.


Since no container class is specified, the standard container std::deque is used 
with his constant complexity of operations.

Time complexity in the worst case
O(n), where n is the number of symbols in the input.

Space comlexity in the worst case
O(n), where n is the number of symbols in the input.
*/

int main() {
  std::ios_base::sync_with_stdio(false);
  std::cin.tie(NULL);

  std::string str;
  std::getline (std::cin, str);
  std::istringstream is(str);

  std::string word;
  std::stack<int> st;
  while( is >> word)
  {
    try
    {
      st.push(std::stoi(word));
    }
    catch (std::invalid_argument const& ex)
    {
      int b = st.top();
      st.pop();
      int a = st.top();
      st.pop();
      switch(word.at(0))
      {
        case '+':
          st.push(a+b);
          break;
        case '-':
          st.push(a-b);
          break;
        case '*':
          st.push(a*b);
          break;
        case '/':
          if(b == 0) {
            throw std::invalid_argument("Division by zero");
          }
          st.push(std::floor(static_cast<double>(a)/b));
          break;
        default:
          throw std::invalid_argument("Invalid operator");
      }
    }
  }
  std::cout << st.top() << std::endl;
}
